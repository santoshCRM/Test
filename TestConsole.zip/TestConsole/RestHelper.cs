﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TestConsole
{
    public class RestHelper
    {
        public delegate T RetryDelegate<out T>();

        public delegate void RetryDelegate();

        private const int RetryCount = 3;

        private const int RetryIntervalMs = 200;

        protected bool IsTableStorage
        {
            get;
            set;
        }

        public string EndPoint
        {
            get;
            internal set;
        }

        public string StorageAccount
        {
            get;
            internal set;
        }

        public string SasKey
        {
            get;
            internal set;
        }

        public RestHelper(string endpoint, string storageAccount, string sasKey)
        {
            EndPoint = endpoint;
            StorageAccount = storageAccount;
            SasKey = sasKey;
        }

        public HttpWebRequest CreateRestRequest(string method, string resource, string requestBody = null, SortedList<string, string> headers = null, string ifMatch = "", string md5 = "")
        {
            byte[] array = null;
            DateTime utcNow = DateTime.UtcNow;
            string requestUriString = EndPoint + resource + SasKey;
            HttpWebRequest httpWebRequest = WebRequest.Create(requestUriString) as HttpWebRequest;
            if (httpWebRequest == null)
            {
                return null;
            }
            httpWebRequest.Method = method;
            httpWebRequest.ContentLength = 0L;
            httpWebRequest.Headers.Add("x-ms-date", utcNow.ToString("R", CultureInfo.InvariantCulture));
            httpWebRequest.Headers.Add("x-ms-version", "2015-12-11");
            if (IsTableStorage)
            {
                httpWebRequest.ContentType = "application/atom+xml";
                httpWebRequest.Headers.Add("DataServiceVersion", "1.0;NetFx");
                httpWebRequest.Headers.Add("MaxDataServiceVersion", "1.0;NetFx");
            }
            if (headers != null)
            {
                foreach (KeyValuePair<string, string> header in headers)
                {
                    httpWebRequest.Headers.Add(header.Key, header.Value);
                }
            }
            if (!string.IsNullOrEmpty(requestBody))
            {
                httpWebRequest.Headers.Add("Accept-Charset", "UTF-8");
                array = Convert.FromBase64String(requestBody);
                httpWebRequest.ContentLength = array.Length;
            }
            if (!string.IsNullOrEmpty(requestBody) && array != null)
            {
                httpWebRequest.GetRequestStream().Write(array, 0, array.Length);
            }
            return httpWebRequest;
        }

        public string GetCanonicalizedHeaders(HttpWebRequest request)
        {
            ArrayList arrayList = new ArrayList();
            StringBuilder stringBuilder = new StringBuilder();
            foreach (string key in request.Headers.Keys)
            {
                if (key.ToLowerInvariant().StartsWith("x-ms-", StringComparison.Ordinal))
                {
                    arrayList.Add(key.ToLowerInvariant());
                }
            }
            arrayList.Sort();
            foreach (string item in arrayList)
            {
                StringBuilder stringBuilder2 = new StringBuilder(item);
                string value = ":";
                foreach (string headerValue in GetHeaderValues(request.Headers, item))
                {
                    string value2 = headerValue.Replace("\r\n", string.Empty);
                    stringBuilder2.Append(value);
                    stringBuilder2.Append(value2);
                    value = ",";
                }
                stringBuilder.Append(stringBuilder2);
                stringBuilder.Append("\n");
            }
            return stringBuilder.ToString();
        }

        public ArrayList GetHeaderValues(NameValueCollection headers, string headerName)
        {
            ArrayList arrayList = new ArrayList();
            string[] values = headers.GetValues(headerName);
            if (values != null)
            {
                string[] array = values;
                foreach (string text in array)
                {
                    arrayList.Add(text.TrimStart(null));
                }
            }
            return arrayList;
        }

        public string GetCanonicalizedResource(Uri address, string accountName)
        {
            StringBuilder stringBuilder = new StringBuilder();
            StringBuilder stringBuilder2 = new StringBuilder("/");
            stringBuilder2.Append(accountName);
            stringBuilder2.Append(address.AbsolutePath);
            stringBuilder.Append(stringBuilder2);
            NameValueCollection nameValueCollection = new NameValueCollection();
            if (!IsTableStorage)
            {
                NameValueCollection nameValueCollection2 = address.ParseQueryString();
                foreach (string key in nameValueCollection2.Keys)
                {
                    ArrayList arrayList = new ArrayList(nameValueCollection2.GetValues(key));
                    arrayList.Sort();
                    StringBuilder stringBuilder3 = new StringBuilder();
                    foreach (object item in arrayList)
                    {
                        if (stringBuilder3.Length > 0)
                        {
                            stringBuilder3.Append(",");
                        }
                        stringBuilder3.Append(item);
                    }
                    nameValueCollection.Add(key?.ToLowerInvariant(), stringBuilder3.ToString());
                }
            }
            ArrayList arrayList2 = new ArrayList(nameValueCollection.AllKeys);
            arrayList2.Sort();
            foreach (string item2 in arrayList2)
            {
                StringBuilder stringBuilder4 = new StringBuilder(string.Empty);
                stringBuilder4.Append(item2);
                stringBuilder4.Append(":");
                stringBuilder4.Append(nameValueCollection[item2]);
                stringBuilder.Append("\n");
                stringBuilder.Append(stringBuilder4);
            }
            return stringBuilder.ToString();
        }

        public static T Retry<T>(RetryDelegate<T> del)
        {
            return Retry(del, 3, 200);
        }

        public static T Retry<T>(RetryDelegate<T> del, int numberOfRetries, int msPause)
        {
            int num = 0;
            while (true)
            {
                try
                {
                    num++;
                    return del();
                }
                catch (Exception)
                {
                    if (num > numberOfRetries)
                    {
                        throw;
                    }
                    if (msPause > 0)
                    {
                        Thread.Sleep(msPause);
                    }
                }
            }
        }

        public static bool Retry(RetryDelegate del)
        {
            return Retry(del, 3, 200);
        }

        public static bool Retry(RetryDelegate del, int numberOfRetries, int msPause)
        {
            int num = 0;
            while (true)
            {
                try
                {
                    num++;
                    del();
                    return true;
                }
                catch (Exception)
                {
                    if (num > numberOfRetries)
                    {
                        throw;
                    }
                    if (msPause > 0)
                    {
                        Thread.Sleep(msPause);
                    }
                }
            }
        }

      
    }
  
}
