﻿using System;
using System.Collections.Generic;
using System.Net;
using System.ServiceModel.Description;
using System.Text;
using System.Runtime.Serialization;
using Microsoft.Xrm.Sdk.Client;
using System.ComponentModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.IO.Compression;
using Microsoft.Xrm.Sdk.Workflow.Activities;
using System.Linq;
using System.Xml;

namespace TestConsole
{
    public class Config
    {
        OrganizationServiceProxy serviceproxy = null;
        public string OrganizationUrl = "https://indiabullsgroupprod.api.crm8.dynamics.com/XRMServices/2011/Organization.svc";//prod
                                                                                                                              // public string OrganizationUrl = "https://indiabullsgroupdev.api.crm8.dynamics.com/XRMServices/2011/Organization.svc";//dev
                                                                                                                              // public string OrganizationUrl = "https://indiabullsgroupsandbox.api.crm8.dynamics.com/XRMServices/2011/Organization.svc";//sandbox
                                                                                                                              //public string OrganizationUrl = "https://k4mobilityltdsb.api.crm8.dynamics.com/XRMServices/2011/Organization.svc";//Demo
        public ClientCredentials Credentials = null;
        public void CreateConnection()
        {


            Credentials = new ClientCredentials();
            Credentials.UserName.UserName = "ibhflsalessupport@indiabullsgroup.onmicrosoft.com";
            Credentials.UserName.Password = "India@123";
            //Credentials.UserName.UserName = "santosh.bhagat@indiabulls.com";
            //Credentials.UserName.Password = "mar@1234";
            //   Credentials.UserName.UserName = "admin@k4mobilityltd.onmicrosoft.com";
            // Credentials.UserName.Password = "K4Mobility@123";
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                serviceproxy = new OrganizationServiceProxy(new Uri(OrganizationUrl), null, Credentials, null);
                Guid orgId = ((WhoAmIResponse)serviceproxy.Execute(new WhoAmIRequest())).OrganizationId;
                Console.Write("connection success !!");



                //RetrieveAllRecordsUsingFetchXML(fetch);
                //getDocumentbodyFromAzure();
                //getEmailDocumentbodyFromAzure();
                //createExceltemplate(serviceproxy);
                //executeAction();
                //getchangerequest();
                //setDocumentbodyFromAzure();
                setEmailDocumentbodyToAzure();
                //setDocumentbodyToAzure();
            }
            catch (Exception ex)
            {
                Console.Write("connection failed !!" + ex.ToString());
            }
        }
        public void ExcecuteM()
        {

            //  serviceproxy.Delete("dynamicproperty", new Guid("979f5e1b-6750-e911-a95d-000d3af2c9d4"));
            //serviceproxy.Retrieve("dynamicproperty", new Guid("979f5e1b-6750-e911-a95d-000d3af2c9d4"), new ColumnSet(true));

            ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
            {

                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = false,
                    ReturnResponses = false
                },
                // Create an empty organization request collection.
                Requests = new OrganizationRequestCollection()
            };
            requestWithResults.Requests.Clear();
            SetStateRequest StateRequest = new SetStateRequest();
            StateRequest.EntityMoniker = new EntityReference("dynamicproperty", new Guid("11c2763d-6350-e911-a95d-000d3af2c9d4"));
            StateRequest.State = new OptionSetValue(2);
            StateRequest.Status = new OptionSetValue(2);
            requestWithResults.Requests.Add(StateRequest);


            ExecuteMultipleResponse responseWithResults = (ExecuteMultipleResponse)serviceproxy.Execute(requestWithResults);

        }


        public void compressNote(string entityName, Guid noteId)
        {
            string text2 = "documentbody";

            using (MemoryStream memoryStream = new MemoryStream())
            {
                using (ZipArchive zipArchive = new ZipArchive(memoryStream, ZipArchiveMode.Update, leaveOpen: false))
                {
                    Entity val5 = serviceproxy.Retrieve(entityName, noteId, new ColumnSet(new string[2]
                    {
                                        "filename",
                                        text2
                    }));
                    if (val5.Attributes.Contains("filename") && val5.Attributes.Contains(text2))
                    {
                        ZipArchiveEntry zipArchiveEntry = zipArchive.CreateEntry(val5.Attributes["filename"].ToString());
                        using (MemoryStream memoryStream2 = new MemoryStream(Convert.FromBase64String(val5.Attributes[text2].ToString())))
                        {
                            using (Stream destination = zipArchiveEntry.Open())
                            {
                                memoryStream2.CopyTo(destination);
                            }
                        }
                    }
                    string text4 = Convert.ToBase64String(memoryStream.ToArray());
                    val5.Attributes[text2] = text4;
                    serviceproxy.Update(val5);
                }



            }


        }
        public void getEmailDocumentbodyFromAzure()
        {
            string[] array = new string[4]
                {
                    "msdyn_name",
                    "msdyn_sastoken",
                    "msdyn_attachmentscontainer",
                    "msdyn_organizationguid"
                };
            QueryExpression val2 = new QueryExpression();
            val2.EntityName = "msdyn_azureblobstoragesetting";
            val2.ColumnSet = (new ColumnSet(array));
            QueryExpression val3 = val2;
            EntityCollection val4 = serviceproxy.RetrieveMultiple(val3);
            string activitymimeattachmentID = "796a0346-6d50-e911-a96f-000d3af076ac";

            ColumnSet columnset = new ColumnSet(new string[1]
                        {
                                    "filename"
                        });
            string fileName = string.Empty;
            Entity noteEnt = serviceproxy.Retrieve("activitymimeattachment", new Guid(activitymimeattachmentID), columnset);
            if (noteEnt.Attributes.Contains("filename"))
            {
                fileName = noteEnt.Attributes["filename"].ToString();
            }
            if (!string.IsNullOrEmpty(fileName))
            {
                fileName = Uri.EscapeDataString(fileName);
            }

            string blob = $"{activitymimeattachmentID}_{fileName}";

            string AccountName = "";
            if (val4.Entities[0].Attributes.Contains("msdyn_name"))
            {
                AccountName = val4.Entities[0].GetAttributeValue<string>("msdyn_name").ToString();
            }
            string SASToken = "";
            if (val4.Entities[0].Attributes.Contains("msdyn_sastoken"))
            {
                SASToken = val4.Entities[0].GetAttributeValue<string>("msdyn_sastoken").ToString();
            }

            BlobHelper blobHelper = new BlobHelper(AccountName, SASToken);


            string containerName = "emailprod";// NotesAttachmentSettings.GetContainerName(regardingObj.get_LogicalName(), azureSettings.TracingService, azureSettings.Service);
            byte[] blob2 = blobHelper.GetBlob(containerName, blob);
            string text2 = Convert.ToBase64String(blob2);

        }
        public void getDocumentbodyFromAzure()
        {
            string[] array = new string[4]
                {
                    "msdyn_name",
                    "msdyn_sastoken",
                    "msdyn_attachmentscontainer",
                    "msdyn_organizationguid"
                };
            QueryExpression val2 = new QueryExpression();
            val2.EntityName = "msdyn_azureblobstoragesetting";
            val2.ColumnSet = (new ColumnSet(array));
            QueryExpression val3 = val2;
            EntityCollection val4 = serviceproxy.RetrieveMultiple(val3);
            string annotationID = "59F3B69E-FE49-E911-A97C-000D3AF07316";

            ColumnSet columnset = new ColumnSet(new string[1]
                        {
                                    "filename"
                        });
            string fileName = string.Empty;
            Entity noteEnt = serviceproxy.Retrieve("annotation", new Guid(annotationID), columnset);
            if (noteEnt.Attributes.Contains("filename"))
            {
                fileName = noteEnt.Attributes["filename"].ToString();
            }
            if (!string.IsNullOrEmpty(fileName))
            {
                fileName = Uri.EscapeDataString(fileName);
            }

            string blob = $"{annotationID}_{fileName}";

            string AccountName = "";
            if (val4.Entities[0].Attributes.Contains("msdyn_name"))
            {
                AccountName = val4.Entities[0].GetAttributeValue<string>("msdyn_name").ToString();
            }
            string SASToken = "";
            if (val4.Entities[0].Attributes.Contains("msdyn_sastoken"))
            {
                SASToken = val4.Entities[0].GetAttributeValue<string>("msdyn_sastoken").ToString();
            }

            BlobHelper blobHelper = new BlobHelper(AccountName, SASToken);


            string containerName = "notesprod";// NotesAttachmentSettings.GetContainerName(regardingObj.get_LogicalName(), azureSettings.TracingService, azureSettings.Service);
            byte[] blob2 = blobHelper.GetBlob(containerName, blob);
            string text2 = Convert.ToBase64String(blob2);

        }
        public void setEmailDocumentbodyToAzure()
        {
            string[] array = new string[4]
                {
                    "msdyn_name",
                    "msdyn_sastoken",
                    "msdyn_attachmentscontainer",
                    "msdyn_organizationguid"
                };
            QueryExpression val2 = new QueryExpression();
            val2.EntityName = "msdyn_azureblobstoragesetting";
            val2.ColumnSet = (new ColumnSet(array));
            QueryExpression val3 = val2;
            EntityCollection val4 = serviceproxy.RetrieveMultiple(val3);
            string AccountName = "";
            if (val4.Entities[0].Attributes.Contains("msdyn_name"))
            {
                AccountName = val4.Entities[0].GetAttributeValue<string>("msdyn_name").ToString();
            }
            string SASToken = "";
            if (val4.Entities[0].Attributes.Contains("msdyn_sastoken"))
            {
                SASToken = val4.Entities[0].GetAttributeValue<string>("msdyn_sastoken").ToString();
            }

            BlobHelper blobHelper = new BlobHelper(AccountName, SASToken);

            String fetchattachmenttransaction = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
"  <entity name='msdyn_attachmenttransaction' >" +
"    <attribute name='msdyn_attachmenttransactionid' />" +
"    <attribute name='msdyn_regardingobjectname' />" +
"    <attribute name='msdyn_regardingobjectid' />" +
"    <attribute name='msdyn_annotationid' />" +
"    <attribute name='msdyn_activitymimeattachmentid' />" +
"    <filter>" +
"      <condition attribute='msdyn_activitymimeattachmentid' operator='not-null' />" +
//"      <condition attribute = 'createdon' operator= 'last-month' /> " +
"    </filter>" +
"    <link-entity name='activitymimeattachment' from='activitymimeattachmentid' to='msdyn_activitymimeattachmentid' link-type='inner' >" +
"      <link-entity name='email' from='activityid' to='activityid' >" +
"        <filter>" +
"          <condition attribute='statuscode' operator='neq' value='6' />" +
"        </filter>" +
"      </link-entity>" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";
            int count = 0;
            EntityCollection coll = RetrieveAllRecordsUsingFetchXML(fetchattachmenttransaction);
            foreach (Entity col in coll.Entities)
            {
                if (!col.Attributes.ContainsKey("msdyn_regardingobjectid"))
                {

                }
                else
                {
                    string regardingobjectid = col.Attributes["msdyn_regardingobjectid"].ToString();
                    string regardingobjectname = col.Attributes["msdyn_regardingobjectname"].ToString();
                    string activitymimeattachmentID = string.Empty;
                    if (col.Attributes.Contains("msdyn_activitymimeattachmentid"))
                    {
                        activitymimeattachmentID = col.Attributes["msdyn_activitymimeattachmentid"].ToString();

                        #region email attach

                        ColumnSet columnset = new ColumnSet(new string[2]
                        {
                                                "filename",
                                                "body"
                        });
                        string fileName = string.Empty;
                        string content = string.Empty;
                        try
                        {
                            Entity noteEnt = serviceproxy.Retrieve("activitymimeattachment", new Guid(activitymimeattachmentID), columnset);
                            if (noteEnt.Attributes.Contains("filename"))
                            {
                                fileName = noteEnt.Attributes["filename"].ToString();
                            }
                            if (noteEnt.Attributes.Contains("body"))
                            {
                                content = noteEnt.Attributes["body"].ToString();
                            }
                            if (!string.IsNullOrEmpty(fileName))
                            {
                                fileName = Uri.EscapeDataString(fileName);
                            }

                            string blob2 = $"{activitymimeattachmentID}_{fileName}";
                            SortedList<string, string> sortedList = null;
                            sortedList = new SortedList<string, string>
                                {
                                    {
                                        "RegardingActivity",
                                        regardingobjectname
                                    },
                                    {
                                        "RegardingActivityId",
                                        regardingobjectid
                                    },
                                    {
                                        "PluginName",
                                        "PostCreateAttachmentTransaction"
                                    }
                        };
                            string containerName = "emailprod";// NotesAttachmentSettings.GetContainerName(regardingObj.get_LogicalName(), azureSettings.TracingService, azureSettings.Service);
                            try
                            {
                                if (!string.IsNullOrEmpty(content))
                                {
                                    noteEnt.Attributes["body"] = (object)null;
                                    noteEnt.EntityState = ((EntityState?)2);
                                    serviceproxy.Update(noteEnt);

                                    bool valres = blobHelper.PutBlob(containerName, blob2, content, sortedList);
                                }
                                count++;

                                serviceproxy.Delete(col.LogicalName, col.Id);
                                Console.WriteLine(count.ToString() + " " + blob2);
                            }
                            catch(System.ServiceModel.FaultException ex)
                            {
                                if (((System.ServiceModel.FaultException)ex).Message.Contains("msdyn_attachmenttransaction"))
                                {
                                    Console.WriteLine(count+" countRecord already deleted" + " "  + blob2);
                                }
                                if (((System.ServiceModel.FaultException)ex).Message.Contains("pending"))
                                {
                                    Console.WriteLine(count+" Pending send email" + " "  + blob2);
                                    count++;
                                }
                            }
                            catch (System.Net.WebException ex)
                            {
                               
                            }
                            catch (Exception ex)
                            {
                               
                            }
                        }
                        catch (Exception ex)
                        {
                            serviceproxy.Delete(col.LogicalName, col.Id);
                        }

                        #endregion
                    }
                }
            }
        }

   


        public void setDocumentbodyToAzure()
        {
            string[] array = new string[4]
                {
                    "msdyn_name",
                    "msdyn_sastoken",
                    "msdyn_attachmentscontainer",
                    "msdyn_organizationguid"
                };
            QueryExpression val2 = new QueryExpression();
            val2.EntityName = "msdyn_azureblobstoragesetting";
            val2.ColumnSet = (new ColumnSet(array));
            QueryExpression val3 = val2;
            EntityCollection val4 = serviceproxy.RetrieveMultiple(val3);
            // string blob = $"000016dd-c7da-e811-a961-000d3af076ac_Selfie.jpg";
         
            string AccountName = "";
            if (val4.Entities[0].Attributes.Contains("msdyn_name"))
            {
                AccountName = val4.Entities[0].GetAttributeValue<string>("msdyn_name").ToString();
            }
            string SASToken = "";
            if (val4.Entities[0].Attributes.Contains("msdyn_sastoken"))
            {
                SASToken = val4.Entities[0].GetAttributeValue<string>("msdyn_sastoken").ToString();
            }

            BlobHelper blobHelper = new BlobHelper(AccountName, SASToken);
            String fetchattachmenttransaction = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
"  <entity name='msdyn_attachmenttransaction' >" +
"    <attribute name='msdyn_attachmenttransactionid' />" +
"    <attribute name='msdyn_regardingobjectname' />" +
"    <attribute name='msdyn_regardingobjectid' />" +
"    <attribute name='msdyn_annotationid' />" +
"    <attribute name='msdyn_activitymimeattachmentid' />" +
"    <filter>" +
"      <condition attribute='msdyn_annotationid' operator='not-null' />" +
"      <condition attribute = 'createdon' operator= 'this-week' /> " +
"    </filter>" +
"  </entity>" +
"</fetch>";
            int count = 0;
            EntityCollection coll = RetrieveAllRecordsUsingFetchXML(fetchattachmenttransaction);
            foreach (Entity col in coll.Entities)
            {
                if (!col.Attributes.ContainsKey("msdyn_regardingobjectid"))
                {

                }
                else
                {
                    string regardingobjectid = col.Attributes["msdyn_regardingobjectid"].ToString();
                    string regardingobjectname = col.Attributes["msdyn_regardingobjectname"].ToString();
                    string annotationID = string.Empty;
                    if (col.Attributes.Contains("msdyn_annotationid"))
                    {
                        annotationID = col.Attributes["msdyn_annotationid"].ToString();

                        #region email attach

                        ColumnSet columnset = new ColumnSet(new string[2]
                        {
                                                "filename",
                                                "documentbody"
                        });
                        string fileName = string.Empty;
                        string content = string.Empty;
                        try
                        {
                            Entity noteEnt = serviceproxy.Retrieve("annotation", new Guid(annotationID), columnset);
                            if (noteEnt.Attributes.Contains("filename"))
                            {
                                fileName = noteEnt.Attributes["filename"].ToString();
                            }
                            if (noteEnt.Attributes.Contains("documentbody"))
                            {
                                content = noteEnt.Attributes["documentbody"].ToString();
                            }
                            if (!string.IsNullOrEmpty(fileName))
                            {
                                fileName = Uri.EscapeDataString(fileName);
                            }

                            string blob2 = $"{annotationID}_{fileName}";
                            SortedList<string, string> sortedList = null;
                            sortedList = new SortedList<string, string>
                                {
                                    {
                                        "RegardingActivity",
                                        regardingobjectname
                                    },
                                    {
                                        "RegardingActivityId",
                                        regardingobjectid
                                    },
                                    {
                                        "PluginName",
                                        "PostCreateAttachmentTransaction"
                                    }
                        };
                            string containerName = "notesprod";
                            try
                            {
                                noteEnt.Attributes["documentbody"] = (object)null;
                                noteEnt.EntityState = ((EntityState?)2);
                                serviceproxy.Update(noteEnt);
                                bool valres = blobHelper.PutBlob(containerName, blob2, content, sortedList);
                                count++;

                                serviceproxy.Delete(col.LogicalName, col.Id);
                                Console.WriteLine(count.ToString() + " " + blob2);
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                        catch (Exception ex)
                        {
                            serviceproxy.Delete(col.LogicalName, col.Id);
                        }

                        #endregion
                    }
                }
            }

        }

        public void createExceltemplate()
        {
            var request = new OrganizationRequest("RenderTemplateFromView");
            request["Template"] = new EntityReference("documenttemplate", new Guid("3BE96B79-D238-E911-A97A-000D3AF07316"));
            request["View"] = new EntityReference("savedquery", new Guid("00000000-0000-0000-00AA-000010001005"));

            var response = serviceproxy.Execute(request);

            var fileContent = (byte[])response["ExcelFile"];

            //Do whatever you need with file content - I saved it to hard drive
            File.WriteAllBytes("GeneratedExcel.xlsx", fileContent);
        }


        public  EntityCollection RetrieveAllRecordsUsingFetchXML(string fetchXML)
        {
            var moreRecords = false;
            int page = 1;
            var cookie = string.Empty;
            int fetchCount = 5000;
            var entityCollection = new EntityCollection();
            do
            {
                string xml = CreateXml(fetchXML, cookie, page, fetchCount);
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(xml)
                };

                var collection =((RetrieveMultipleResponse) serviceproxy.Execute(fetchRequest1)).EntityCollection;

                if (collection.Entities.Count > 0)
                {
                    // Do work
                    entityCollection.Entities.AddRange(collection.Entities);
                }

                moreRecords = collection.MoreRecords;
                if (moreRecords)
                {
                    page++;
                    cookie = collection.PagingCookie;
                }
                Console.WriteLine(entityCollection.Entities.Count);
            } while (moreRecords);

            return entityCollection;
        }
        public void  getchangerequest()
        {
            string token = "";

            var records = new List<Entity>();

            var request = new RetrieveEntityChangesRequest();
            request.EntityName = "fieldsecurityprofile";
            request.Columns = new ColumnSet(true);
            //request.Parameters.Add("fieldsecurityprofileid", new Guid("AEA580EF-11CE-E811-A961-000D3AF07316"));
            request.PageInfo = new PagingInfo() { Count = 5000, PageNumber = 1, ReturnTotalRecordCount = false };
            request.DataVersion = token;

            while (true)
            {
                RetrieveEntityChangesResponse response = (RetrieveEntityChangesResponse)serviceproxy.Execute(request);
                foreach(NewOrUpdatedItem myItem in   response.EntityChanges.Changes)
                {
                    if(myItem.NewOrUpdatedEntity.Id==new Guid("AEA580EF-11CE-E811-A961-000D3AF07316"))
                    {

                    }
                    
                }

                //((Microsoft.Xrm.Sdk.NewOrUpdatedItem)(new System.Collections.Generic.Mscorlib_CollectionDebugView<Microsoft.Xrm.Sdk.IChangedItem>(response.EntityChanges.Changes).Items[0])).NewOrUpdatedEntity.Id
                //    AEA580EF - 11CE - E811 - A961 - 000D3AF07316
                //records.AddRange(response.EntityChanges.Changes..Select(x => (x as NewOrUpdatedItem).NewOrUpdatedEntity).ToArray());
                records.ForEach(x => Console.WriteLine(x.Id));
                if (!response.EntityChanges.MoreRecords)
                {
                    token = response.EntityChanges.DataToken;
                    Console.WriteLine(token);
                    break;
                }

                request.PageInfo.PageNumber++;
                request.PageInfo.PagingCookie = response.EntityChanges.PagingCookie;
            }
        }
        public void executeAction()
        {

            OrganizationRequest val = new OrganizationRequest("bg_Render");
           // SetParameter(val);
            val.Parameters.Add("Target", new EntityReference("report", new Guid("DA1A9AFE-682F-E911-A971-000D3AF29D99")));
            val.Parameters.Add("Format", "PDF");
           OrganizationResponse response= serviceproxy.Execute(val);
            ParameterCollection comm = response.Results;
            var valu= comm.Values;

            string[] base64BinaryStr = new string[1];
            valu.CopyTo(base64BinaryStr, 0);
            Entity ActivityMimeAttachment = new Entity("activitymimeattachment");
            ActivityMimeAttachment["subject"] = "report name";
            ActivityMimeAttachment["filename"] = "ExampleAttachment.pdf";
            ActivityMimeAttachment["body"] = base64BinaryStr[0];
            ActivityMimeAttachment["attachmentnumber"] = 1;

            ActivityMimeAttachment["objectid"] = new EntityReference("email", new Guid("E7B7D1E5-722F-E911-A971-000D3AF29D99"));
            ActivityMimeAttachment["objecttypecode"] = "email";




            serviceproxy.Create(ActivityMimeAttachment);


    //        byte[] bytes = Convert.FromBase64String(base64BinaryStr[0]);
    //        System.IO.FileStream stream =
    //new FileStream(@"d:\file.pdf", FileMode.CreateNew);
    //        System.IO.BinaryWriter writer =
    //            new BinaryWriter(stream);
    //        writer.Write(bytes, 0, bytes.Length);
    //        writer.Close();
        }
        public string CreateXml(string xml, string cookie, int page, int count)
        {
            StringReader stringReader = new StringReader(xml);
            XmlTextReader reader = new XmlTextReader(stringReader);

            // Load document
            XmlDocument doc = new XmlDocument();
            doc.Load(reader);

            return CreateXml(doc, cookie, page, count);
        }

        public string CreateXml(XmlDocument doc, string cookie, int page, int count)
        {
            XmlAttributeCollection attrs = doc.DocumentElement.Attributes;

            if (cookie != null)
            {
                XmlAttribute pagingAttr = doc.CreateAttribute("paging-cookie");
                pagingAttr.Value = cookie;
                attrs.Append(pagingAttr);
            }

            XmlAttribute pageAttr = doc.CreateAttribute("page");
            pageAttr.Value = System.Convert.ToString(page);
            attrs.Append(pageAttr);

            XmlAttribute countAttr = doc.CreateAttribute("count");
            countAttr.Value = System.Convert.ToString(count);
            attrs.Append(countAttr);

            StringBuilder sb = new StringBuilder(1024);
            StringWriter stringWriter = new StringWriter(sb);

            XmlTextWriter writer = new XmlTextWriter(stringWriter);
            doc.WriteTo(writer);
            writer.Close();

            return sb.ToString();
        }

    }
}
