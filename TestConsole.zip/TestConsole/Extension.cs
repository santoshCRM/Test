﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{

    public static class Extension
    {
        public static NameValueCollection ParseQueryString(this Uri uri)
        {
            NameValueCollection nameValueCollection = new NameValueCollection();
            if (string.IsNullOrWhiteSpace(uri.Query))
            {
                return nameValueCollection;
            }
            string text = uri.Query.Remove(0, 1);
            string[] source = text.Split('&');
            foreach (string[] item in from s in source
                                      select s.Split('='))
            {
                nameValueCollection.Add(item[0], WebUtility.UrlDecode(item[1]));
            }
            return nameValueCollection;
        }

        public static Dictionary<string, dynamic> Parse(this string value)
        {
            if (string.IsNullOrEmpty(value)) return null;

            var settings = new DataContractJsonSerializerSettings()
            {
                UseSimpleDictionaryFormat = true
            };

            var serializer = new DataContractJsonSerializer(typeof(Dictionary<string, dynamic>), settings);
            using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(value)))
            {
                return serializer.ReadObject(stream) as Dictionary<string, dynamic>;
            }
        }
    }
}
